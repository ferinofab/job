<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$user_id = $_GET['user_id'];
$apply = $pdo->query("SELECT * FROM apply JOIN crud WHERE apply.user_id='$user_id' AND apply.id_vac=crud.id")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<H1>Отклики на вакансии</H1>
<?php if($apply):?>
<?php foreach ($apply as $item):?>
        <P>Название вакансии - <?=$item['vac_name']?></P>
        <p>отклик</p>
        <p>Имя - <?=$item['name']?></p>
        <p>Email - <?=$item['email']?></p>
        <p>Link - <?=$item['link']?></p>
<?php endforeach;?>
<?php else:?>
<p>откликов нет</p>
<?php endif;?>


</body>
</html>