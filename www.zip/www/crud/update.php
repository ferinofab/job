<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$category = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
$name = $_GET['name'];
$price = $_GET['price'];
$cat = $_GET['cat'];
$id = $_GET['id'];

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="/auth/update.php" method="post">
    <lable>name</lable>
    <input type="text" value="<?=$name?>" name="name">
    <lable>price</lable>
    <input type="number" value="<?=$price?>" name="price">
    <lable>category</lable>
    <select name="cat">
        <?php foreach($category as $item):?>
            <option value="<?= $item['id']?>"><?=$item['name']?></option>
        <?php endforeach;?>
        </select><br>
    <input type="text" value="<?=$id?>" hidden name="id">
    <input type="submit">
</form>
</body>
</html>
