<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$name = $_POST['name'];
$price = $_POST['price'];
$cat = $_POST['cat'];
$id = $_POST['id'];
$pdo->query("UPDATE crud SET name='$name', 	price='$price', category_id='$cat' WHERE id='$id'");
header("Location: /index.php");