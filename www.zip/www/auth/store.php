<?php
session_start();
$user_id =  $_SESSION['user_id'];
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$name = $_POST['name'];
$slug = $_POST['slug'];
$price = $_POST['price'];
$type_of_employment = $_POST['type_of_employment'];
$experience = $_POST['experience'];
$skill_level = $_POST['skill_level'];
$description = $_POST['description'];
$select = $_POST['select'];

$pdo -> query("insert into crud (name, slug, price, category_id, type_of_employment, 	experience, skill_level, description, user_id, cat_id) value ('$name', '$slug' ,'$price', '$select', '$type_of_employment', '$experience', '$skill_level', '$description', '$user_id','$select')");
header("Location: /index.php");