<?php
session_start();

require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$company_name = $_POST['company_name'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$select = $pdo -> query("SELECT * FROM users WHERE email = $email AND pass = $pass")->fetch(PDO::FETCH_ASSOC);



if($select){
    header('Location: /reg/login.php');
}else{
     $pdo->query("INSERT INTO users (company_name, email, pass) VALUES ($company_name, $email, $pass)");
     $select = $pdo -> query("SELECT * FROM users WHERE email = $email AND pass = $pass")->fetch(PDO::FETCH_ASSOC);
     $_SESSION['user_id'] = $select['id'];
}
header("Location: /index.php");



