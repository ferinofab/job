<?php
$cat = $_POST['category'];
