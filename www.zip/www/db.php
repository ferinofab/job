<?php

//$pdo = new PDO('mysql:host=database;dbname=job', 'root', 'tiger');
//return $pdo;

$pdo = new PDO('mysql:host=MySQL-8.2;dbname=job', 'root', '');
return $pdo;