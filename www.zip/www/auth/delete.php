<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$id = $_GET['id'];
$pdo->query("DELETE FROM crud WHERE id='$id'");
