<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$link = $_POST['link'];
$file = $_POST['file'];
$desc = $_POST['desc'];
$id_vac  = $_POST['id_vac'];
$vac_name = $_POST['vac_name'];
$user_id = $_POST['user_id'];

$pdo->query("INSERT INTO apply (name, email, description, id_vac, vac_name, user_id, link) VALUES ('$name', '$email', '$desc', '$id_vac', '$vac_name', '$user_id','$link' )");

header("Location: /index.php");
