<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$name = $_POST['name'];
$id = $_POST['id'];

$path = "/uploads/" . $_FILES['img']['name'];
move_uploaded_file($_FILES['img']['tmp_name'], $_SERVER["DOCUMENT_ROOT"] . $path);
$pdo->query("UPDATE users SET company_name='$name', image='$path' where id='$id'");
header("Location: /index.php");